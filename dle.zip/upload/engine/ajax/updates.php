<?php
echo <<<HTML
<div class="ui-state-error ui-corner-all" style="padding:10px;"><b>Attention!</b>
<br />To avoid problems, for security reasons, checking for updates is disabled!
</div>
HTML;
?>